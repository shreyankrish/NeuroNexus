
import FormContainer from "../components/FormContainer";

const Index = () => {
  return (
    <div className="min-h-screen flex items-center justify-center bg-purple-50 p-4">
      <FormContainer />
    </div>
  );
};

export default Index;
